
Quick pointers for next time:
- Read [docs/guide.md](cci:7://file:///Users/ajaydahal/portal/agency_research/code/docs/guide.md:0:0-0:0) for a full orientation.
- Run seeds: POST `/countries/seedv1`, `/job-titles/seedv1`.
- Key flows to try:
  - Candidate matching: `GET /candidates/:id/relevant-jobs`, `/grouped`, `/by-title`.
  - Apply + status updates: `POST /applications` then shortlist/schedule/complete/withdraw.
  - Agency analytics: `GET /agencies/:license/analytics/applicants-by-phase`.
- Full tests: `npm test -- --runInBand`.
